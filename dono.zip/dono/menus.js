//NÃO MEXA NO (donoName, botName, prefixo, timed, data, hora) SE NÃO SOUBER PARA OQ SERVE, MEXA SOMENTE NO TEXTO DO MENU
const menu = ( donoName, botName, prefixo, timed, data, hora, totalCmd, moji, emoji, pushname  ) => { 
return `┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊     ✰✰✰ ᗷᗴᗰ ᐯIᑎᗪO (ᗩ) ★★★
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊╭ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╮
┊┊🐦‍🔥 𝚄𝚂𝚄𝙰𝚁𝙸𝙾: ${pushname}
┊┊🐦‍🔥 𝙳𝙾𝙽𝙾: ${donoName}
┊┊🐦‍🔥 𝙱𝙾𝚃: ${botName}
┊┊🐦‍🔥 𝙷𝙾𝚁𝙰: ${hora}
┊┊🐦‍🔥 𝙳𝙰𝚃𝙰: ${data}
┊┊🐦‍🔥 𝚃𝙾𝚃𝙰𝙻𝙲𝙼𝙳: ${totalCmd}
┊┊🐦‍🔥 𝚅𝙴𝚁𝚂𝙰̃𝙾: 
┊┊🐦‍🔥 𝙴𝙳𝙸𝙲̧𝙰̃𝙾: *𝙻𝙾𝚅𝙴𝙱𝚈𝚃𝙴 𝚄𝙿𝙳𝙰𝚃𝙴* 🐦‍🔥
┊╰ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╯
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎  


  
 

‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊ 『 🐦‍🔥 』  𝐃𝐈𝐕𝐄𝐑𝐒❍̸𝐒 𝐌𝐄𝚴𝐔𝐒 『 🐦‍🔥 』
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Menudono ↝『𝙳𝙾𝙽𝙾𝚂』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Menuadm ↝『𝙰𝙳𝙼𝚂』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Menulogos ↝『𝙻𝙾𝙶𝙾𝚂』 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Menuvip ↝『𝚅𝙸𝙿𝚂』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Menurpg
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Menubrincadeiras
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊『 🐦‍🔥 』 𝐈𝐍𝐅❍̸𝐑𝐌𝐀𝐓𝐈𝐕𝐎𝐒  『 🐦‍🔥 』  
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘ 
╎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}criador
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}design
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}misa-responde
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}bug
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}novocmd
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}avaliar 
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊ 『 🐦‍🔥 』 𝐑𝐀𝐍𝐃𝐎𝐌-𝐂𝐌𝐃𝐒 『 🐦‍🔥 』  
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘ 
╎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}atestado
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}fakechat 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}calcular
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}fala
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gerarnick
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gerarnick2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}say
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}piada
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}linknunber
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}pegar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}logomodz
┊╭──────────────────────
┊│ _🐦‍🔥 𝐏𝐄𝐒𝐐𝐔𝐈𝐒𝐀𝐒 🐦‍🔥_
┊╰──────────────────────
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}pinterest
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}series
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}filmes
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}idade
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}metadinha
┊╭──────────────────────
┊│_🐦‍🔥 𝐌𝐈𝐃𝐈𝐀𝐒 𝐄 𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒 🐦‍🔥_
┊╰──────────────────────
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gerarlink2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}attp1
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}attp2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}attp3
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}attp4
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}attp5
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}sticker
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}playvideo
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}play
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}instamp3
┊╭──────────────────────
┊│ _🐦‍🔥 𝐎𝐍𝐋𝐘 𝐃𝐀 𝟓 ${botName}🐦‍🔥_
┆╰──────────────────────
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only1
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only3
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only4
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only5
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only6
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only7
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only8
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}only9
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝
`
}
exports.menu = menu

const menuAdm = ( donoName, botName, prefixo, timed, data, hora, totalCmd, moji, emoji, pushname ) => { 
return `
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊     ✰✰✰ ᗷᗴᗰ ᐯIᑎᗪO (ᗩ) ★★★
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊╭ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╮
┊┊🐦‍🔥 𝚄𝚂𝚄𝙰𝚁𝙸𝙾: ${pushname}
┊┊🐦‍🔥 𝙳𝙾𝙽𝙾: ${donoName}
┊┊🐦‍🔥 𝙱𝙾𝚃: ${botName}
┊┊🐦‍🔥 𝙷𝙾𝚁𝙰: ${hora}
┊┊🐦‍🔥 𝙳𝙰𝚃𝙰: ${data}
┊┊🐦‍🔥 𝚃𝙾𝚃𝙰𝙻𝙲𝙼𝙳: ${totalCmd}
┊┊🐦‍🔥 𝚅𝙴𝚁𝚂𝙰̃𝙾: *𝚅1.6.0* 🐦‍🔥
┊┊🐦‍🔥 𝙴𝙳𝙸𝙲̧𝙰̃𝙾: *𝙻𝙾𝚅𝙴𝙱𝚈𝚃𝙴 𝚄𝙿𝙳𝙰𝚃𝙴* 🐦‍🔥
┊╰ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╯
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎  


  
 

‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
‏┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊ 『 🐦‍🔥 』 𝐌𝐄𝐍𝐔 𝐀𝐃𝐌  『 🐦‍🔥 』
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}ban
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}grupo (a/f)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}antilink (1/0)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}bemvindo (1/0)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}modorpg (1/0)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}modobrincadeiras (1/0)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}autofig (1/0)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}antisticker (1/0)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}ativacoes
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}legendabv 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}legendasaiu
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}resetlink
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}nomegp
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}delete
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}linkgp
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}promover 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rebaixar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}soli
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}totag
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}marcar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}marcar2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}marcarwa
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}limpar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}listabr
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}listafake
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}grupin (30𝑠 | 1𝑚 | 5𝑚 | 10𝑚 | 30𝑚 | 1ℎ | 3ℎ | 12ℎ)
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝`
}
exports.menuAdm = menuAdm

const menuDono = ( donoName, botName, prefixo, timed, data, hora, totalCmd, moji, emoji, pushname ) => { 
return `┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊     ✰✰✰ ᗷᗴᗰ ᐯIᑎᗪO (ᗩ) ★★★
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊╭ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╮
┊┊🐦‍🔥 𝚄𝚂𝚄𝙰𝚁𝙸𝙾: ${pushname}
┊┊🐦‍🔥 𝙳𝙾𝙽𝙾: ${donoName}
┊┊🐦‍🔥 𝙱𝙾𝚃: ${botName}
┊┊🐦‍🔥 𝙷𝙾𝚁𝙰: ${hora}
┊┊🐦‍🔥 𝙳𝙰𝚃𝙰: ${data}
┊┊🐦‍🔥 𝚃𝙾𝚃𝙰𝙻𝙲𝙼𝙳: ${totalCmd}
┊┊🐦‍🔥 𝚅𝙴𝚁𝚂𝙰̃𝙾: *𝚅1.6.0* 🐦‍🔥
┊┊🐦‍🔥 𝙴𝙳𝙸𝙲̧𝙰̃𝙾: *𝙻𝙾𝚅𝙴𝙱𝚈𝚃𝙴 𝚄𝙿𝙳𝙰𝚃𝙴* 🐦‍🔥
┊╰ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╯
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘
‏┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊ 『 🐦‍🔥 』 𝐌𝐄𝐍𝐔 𝐃𝐎𝐍❍̸𝐒  『 🐦‍🔥 』
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}reset
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}ping
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}seradm
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}sermembro
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}servip
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}bangp
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}unbangp
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}botoff
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}boton
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}addvip
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}delvip
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}mudarbio
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}sairgp
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}listagp
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}cases
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}transmitir
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}getcase2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}getcase
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}newcase
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}nick-dono
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}nome-bot
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}setprefix 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}numero-dono
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}antipv
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}addpix
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}delpix
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}setpix
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}soltar 
┊ ⃟
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 bom, se voce entende de bot e tals vai saber usar isso, caso contrário 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 nao mexa em nada.
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 $ ls
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 > info 
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝`
}
exports.menuDono = menuDono

const menubrincadeiras = ( donoName, botName, prefixo, timed, data, hora, totalCmd, moji, emoji, pushname ) => { 
return `
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊     ✰✰✰ ᗷᗴᗰ ᐯIᑎᗪO (ᗩ) ★★★
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊╭ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╮
┊┊🐦‍🔥 𝚄𝚂𝚄𝙰𝚁𝙸𝙾: ${pushname}
┊┊🐦‍🔥 𝙳𝙾𝙽𝙾: ${donoName}
┊┊🐦‍🔥 𝙱𝙾𝚃: ${botName}
┊┊🐦‍🔥 𝙷𝙾𝚁𝙰: ${hora}
┊┊🐦‍🔥 𝙳𝙰𝚃𝙰: ${data}
┊┊🐦‍🔥 𝚃𝙾𝚃𝙰𝙻𝙲𝙼𝙳: ${totalCmd}
┊┊🐦‍🔥 𝚅𝙴𝚁𝚂𝙰̃𝙾: *𝚅1.6.0* 🐦‍🔥
┊┊🐦‍🔥 𝙴𝙳𝙸𝙲̧𝙰̃𝙾: *𝙻𝙾𝚅𝙴𝙱𝚈𝚃𝙴 𝚄𝙿𝙳𝙰𝚃𝙴* 🐦‍🔥
┊╰ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╯
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘
‏┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊ 『 🐦‍🔥 』 𝐌𝐄𝐍𝐔 𝐁𝐑𝐈𝐍𝐂𝐀𝐃𝐄𝐈𝐑𝐀𝐒  『 🐦‍🔥 』
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}morte 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}chifre 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}pau
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}vdd-dsf
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}eununca 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gostoso (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gostosa (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}corno (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}vesgo (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}bebado (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gado (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gostosa (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}feio (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}dogolpe (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gay (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}beijo (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}tapa (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}chute (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}nazista (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}mata (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}louça (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}shipo (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}pgpau (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}pgbunda (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}morder (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}sentar (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}pgpeito (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}capinarlote (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Abraço (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Estuprar (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Tirarft (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Cu (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Cagar (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Boquete (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}linda (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}lindo (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}fiel (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}casal (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gozar (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Sigma (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Beta (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Baiano (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Baiana (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Carioca (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Louco (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Louca (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Safada (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Safado (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Macaca (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Macaco (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Puta (@)
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}tagme (@)
╎╭──────────────────────
╎╎     *🌙 𝐓𝐎𝐏 𝟓-𝐑𝐀𝐍𝐊 🌙*
┆╰──────────────────────
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankpau
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankgay
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankgado
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}ranknazista
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankcorno
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankgostoso
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankotaku
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Ranksigma 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Rankbeta 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Rankbaiano 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Rankbaiana 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Rankcarioca 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Ranksafado 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Ranksafada 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Ranklouco 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Ranklouca 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Rankmacaco 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Rankmacaca 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}Rankputa 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankcu 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankbct
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankfalido 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}rankcasal  ‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>qq<▬▭▬✩▬▭▬✧╝`
}
exports.menubrincadeiras = menubrincadeiras 

const menuvip = (donoName, botName, prefixo, timed, data, hora, totalCmd, pushname) => {
return `
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊     ✰✰✰ ᗷᗴᗰ ᐯIᑎᗪO (ᗩ) ★★★
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊╭ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╮
┊┊🐦‍🔥 𝚄𝚂𝚄𝙰𝚁𝙸𝙾: ${pushname}
┊┊🐦‍🔥 𝙳𝙾𝙽𝙾: ${donoName}
┊┊🐦‍🔥 𝙱𝙾𝚃: ${botName}
┊┊🐦‍🔥 𝙷𝙾𝚁𝙰: ${hora}
┊┊🐦‍🔥 𝙳𝙰𝚃𝙰: ${data}
┊┊🐦‍🔥 𝚃𝙾𝚃𝙰𝙻𝙲𝙼𝙳: ${totalCmd}
┊┊🐦‍🔥 𝚅𝙴𝚁𝚂𝙰̃𝙾: *𝚅1.6.0* 🐦‍🔥
┊┊🐦‍🔥 𝙴𝙳𝙸𝙲̧𝙰̃𝙾: *𝙻𝙾𝚅𝙴𝙱𝚈𝚃𝙴 𝚄𝙿𝙳𝙰𝚃𝙴* 🐦‍🔥
┊╰ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╯
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘
‏┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊ 『 🐦‍🔥 』 𝐌𝐄𝐍𝐔 𝐕𝐈𝐏  『 🐦‍🔥 』
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}plaq1 *( nome )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}plaq2 *( nome )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}plaq3 *( nome )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}plaq4 *( nome )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}plaq5 *( nome )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}plaq6 *( nome )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}plaq7 *( nome )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}likeff *( id ff )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}ddd *( 83 )*
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}gerarcpf
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}marukarv
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}netersg
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}egril18
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}princesa
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}carniello
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}vitacelestine
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}onlyfansvideo
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}marinamui
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}laynuniz
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}isawaifu
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}isadoramartinez
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}onlyfans
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}presentinho
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}presentinho2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}pack+18
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}site-hentai
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}site-hentai2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}site-xvideos
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}site-xvideos2
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}rule34
┊┊ ⃟⃝⃪⃘ 🐦‍🔥🐦‍🔥 ${prefixo}hentai
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝`
}
exports.menuVip = menuvip

const menuRpg = (donoName, botName, prefixo, timed, data, hora, totalCmd, pushname) => {
return `
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊     ✰✰✰ ᗷᗴᗰ ᐯIᑎᗪO (ᗩ) ★★★
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊╭ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╮
┊┊🐦‍🔥 𝚄𝚂𝚄𝙰𝚁𝙸𝙾: ${pushname}
┊┊🐦‍🔥 𝙳𝙾𝙽𝙾: ${donoName}
┊┊🐦‍🔥 𝙱𝙾𝚃: ${botName}
┊┊🐦‍🔥 𝙷𝙾𝚁𝙰: ${hora}
┊┊🐦‍🔥 𝙳𝙰𝚃𝙰: ${data}
┊┊🐦‍🔥 𝚃𝙾𝚃𝙰𝙻𝙲𝙼𝙳: ${totalCmd}
┊┊🐦‍🔥 𝚅𝙴𝚁𝚂𝙰̃𝙾: *𝚅1.6.0* 🐦‍🔥
┊┊🐦‍🔥 𝙴𝙳𝙸𝙲̧𝙰̃𝙾: *𝙻𝙾𝚅𝙴𝙱𝚈𝚃𝙴 𝚄𝙿𝙳𝙰𝚃𝙴* 🐦‍🔥  
┊╰ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╯
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘
‏┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊ 『 🐦‍🔥 』 𝐌𝐄𝐍𝐔 𝐑𝐏𝐆  『 🐦‍🔥 』
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}lojarpg 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}inventario 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}usar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}curar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}plantar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}comprar-animal
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}criar-filhote
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}missao 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}coletar 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}comprar 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}fazenda
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}statusrpg
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}caçar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}criarfamilia 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}verfamilia 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}sairfamilia 
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}adicionarfamilia
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}addfamilia
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}vertodasfamilia
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}minerar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}carteira
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}trabalhar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}treinar
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}cassino
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}meupix
┊┊ ⃟⃝⃪⃘ 🐦‍🔥${prefixo}chavepix
╎╭──────────────────────
╎╎     *🌙 𝐑𝐀𝐍𝐊 🌙*
┆╰──────────────────────
┊┊ ⃟⃝⃪⃘ ❤🐦‍🔥‍🩹 ${prefixo}rankcity
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝`
}
exports.menuRpg = menuRpg

const menuLogos = ( donoName, botName, prefixo, timed, data, hora, totalCmd, moji, emoji, pushname ) => { 
return `

┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊     ✰✰✰ ᗷᗴᗰ ᐯIᑎᗪO (ᗩ) ★★★
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘    
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊╭ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╮
┊┊🐦‍🔥 𝚄𝚂𝚄𝙰𝚁𝙸𝙾: ${pushname}
┊┊🐦‍🔥 𝙳𝙾𝙽𝙾: ${donoName}
┊┊🐦‍🔥 𝙱𝙾𝚃: ${botName}
┊┊🐦‍🔥 𝙷𝙾𝚁𝙰: ${hora}
┊┊🐦‍🔥 𝙳𝙰𝚃𝙰: ${data}
┊┊🐦‍🔥 𝚃𝙾𝚃𝙰𝙻𝙲𝙼𝙳: ${totalCmd}
┊┊🐦‍🔥 𝚅𝙴𝚁𝚂𝙰̃𝙾: *𝚅1.6.0* 🐦‍🔥
┊┊🐦‍🔥 𝙴𝙳𝙸𝙲̧𝙰̃𝙾: *𝙻𝙾𝚅𝙴𝙱𝚈𝚃𝙴 𝚄𝙿𝙳𝙰𝚃𝙴* 🐦‍🔥
┊╰ ── ┉┉─「 🐦‍🔥 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝
╎
┌─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┐
┊ 『 🐦‍🔥 』  𝐌𝐄𝐍𝐔 𝐋𝐎𝐆𝐎𝐒『 🐦‍🔥 』  
└─*̥˚˚*ੈ‧₊˚୨୧⋆ ˚｡⋆『🐦‍🔥』⋆ ˚｡⋆୨୧˚*ੈ‧₊˚*̥˚─┘ 
╎
╔✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╗
┊╭ ── ┉┉─「 🪦 」─┉┉ ── ╮
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}grafite 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}grafite2 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}horror 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}colorido 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}desfoque 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}zombie 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}naruto 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}aniversario 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}amongus 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}glitch 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}write 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}advancedglow 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}typography 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}pixelglitch 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}neonglitch 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}flag 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}flag3d 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}deleting 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}blackpink 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}glowing 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}watercolor 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}papercut 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}cartoon 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}logomaker 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}underwater 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}luxurygold 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}summerbeach 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}gradient 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}blackpinklogo 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}effectclouds 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}darkgreen 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}lighteffects 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}dragonball 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}neondevil 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}1917 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}galaxywallpaper 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}makingneon 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}royal 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}freecreate 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}galaxy 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}frozen 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}wooden3d 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}metal3d  『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}ligatures 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}3druby 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}sunset 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}cemetery 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}halloween 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}blood 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}joker 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}clouds 『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}logohacker『 ᵀᴱᵡᵀ 』
┊┊ ⃟⃝⃪⃘ 🐦‍🔥 ${prefixo}logomisterio『 ᵀᴱᵡᵀ 』
┊╰ ── ┉┉─「 🪦 」─┉┉ ── ╯
╚✧▬▭▬✩▬▭▬>🐦‍🔥<▬▭▬✩▬▭▬✧╝┃
`
}
exports.menuLogos = menuLogos

