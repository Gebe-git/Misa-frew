const fs = require('fs');
const familiasPath = './MISA-BANKER/usuarios/misarpg/familias.json';

const loadFamilias = () => {
  try {
    const data = JSON.parse(fs.readFileSync(familiasPath));
    if (!data || !Array.isArray(data.familias)) {
      return { familias: [] };
    }
    return data;
  } catch (err) {
    console.error('Erro ao carregar famílias:', err);
    return { familias: [] };
  }
};

const saveFamilias = (familias) => {
  try {
    fs.writeFileSync(familiasPath, JSON.stringify(familias, null, 2));
  } catch (err) {
    console.error('Erro ao salvar famílias:', err);
  }
};

const isUserInFamily = (sender) => {
  const familias = loadFamilias();
  const listaFamilias = familias.familias || [];
  return listaFamilias.some(f => f.membros.includes(sender));
};

const criarFamilia = (sender, nomeFamilia) => {
  const familias = loadFamilias();
  if (isUserInFamily(sender)) {
    return 'Você já faz parte de uma família.';
  }

  const nomeFamiliaNormalizado = nomeFamilia.trim().toLowerCase();
  if (familias.familias.some(f => f.nome.trim().toLowerCase() === nomeFamiliaNormalizado)) {
    return 'Já existe uma família com esse nome.';
  }

  const novaFamilia = {
    chefe: sender,
    nome: nomeFamilia.trim(),
    membros: [sender]
  };

  familias.familias.push(novaFamilia);
  saveFamilias(familias);
  return `Família '${novaFamilia.nome}' criada com sucesso!`;
};

const adicionarFamilia = (sender, membroParaAdicionar) => {
  const familias = loadFamilias();
  if (isUserInFamily(membroParaAdicionar)) {
    return 'Este membro já faz parte de uma família.';
  }
  const familia = familias.familias.find(f => f.chefe === sender);
  if (!familia) {
    return 'Você precisa criar uma família primeiro.';
  }
  if (familia.membros.includes(membroParaAdicionar)) {
    return 'Este membro já está na sua família.';
  }
  familia.membros.push(membroParaAdicionar);
  saveFamilias(familias);
  return `Membro adicionado à família '${familia.nome}' com sucesso!`;
};

const sairFamilia = (sender) => {
  const familias = loadFamilias();
  const familiaIndex = familias.familias.findIndex(f => f.membros.includes(sender));
  if (familiaIndex === -1) {
    return 'Você não está em uma família.';
  }
  const familia = familias.familias[familiaIndex];
  familia.membros = familia.membros.filter(m => m !== sender);
  // Se o chefe sair ou não restar membros, desfaz a família
  if (familia.membros.length === 0 || familia.chefe === sender) {
    familias.familias.splice(familiaIndex, 1);
    saveFamilias(familias);
    return `Você saiu e a família '${familia.nome}' foi desfeita.`;
  }
  saveFamilias(familias);
  return `Você saiu da família '${familia.nome}'.`;
};

const verFamilia = (sender) => {
  const familias = loadFamilias();
  const familia = familias.familias.find(f => f.membros.includes(sender));
  if (!familia) {
    return 'Você não está em uma família.';
  }
  const membrosFamilia = familia.membros.map(member => `@${member.split('@')[0]}`).join(', ');
  return `Família '${familia.nome}':\nMembros: ${membrosFamilia}`;
};

const verTodasFamilias = () => {
  const familias = loadFamilias();
  if (!familias.familias || familias.familias.length === 0) {
    return 'Nenhuma família foi criada ainda.';
  }
  let resultado = '👨‍👩‍👧‍👦 Todas as Famílias:\n\n';
  familias.familias.forEach(familia => {
    const membrosFamilia = familia.membros.map(member => `@${member.split('@')[0]}`).join(', ');
    resultado += `Família '${familia.nome}':\nChefe: @${familia.chefe.split('@')[0]}\nMembros: ${membrosFamilia}\n\n`;
  });
  return resultado.trim();
};

module.exports = {
  criarFamilia,
  adicionarFamilia,
  sairFamilia,
  verFamilia,
  verTodasFamilias,
  isUserInFamily,
  loadFamilias,
  saveFamilias
};